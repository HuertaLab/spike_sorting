function writemda32(X,fname)
writemda(X,fname,'float32');
end