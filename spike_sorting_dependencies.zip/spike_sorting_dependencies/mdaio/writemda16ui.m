function writemda16ui(X,fname)
writemda(X,fname,'uint16');
end